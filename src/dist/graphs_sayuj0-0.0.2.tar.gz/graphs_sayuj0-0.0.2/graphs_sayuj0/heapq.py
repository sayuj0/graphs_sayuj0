from heapq import heappush, heappop

__all__ = ["heappush", "heappop"]
